# ⚡ Inicio Rápido: JADSlink en Hostinger (MySQL)

## 📦 1. Subir a Hostinger

```bash
# File Manager: /home/u938946830/
# Upload: jadslink-deploy-mysql.tar.gz
# Click derecho → Extract
```

## 2. Configurar .env

```bash
cd jadslink-deploy
cp api/.env.hostinger .env
nano .env

# Actualizar:
# DATABASE_URL=mysql+aiomysql://usuario:contraseña@localhost:3306/basedatos
```

**Obtén credenciales de**: Panel Hostinger → Bases de Datos

## 3. Instalar & Setup

```bash
cd api
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Migraciones
alembic upgrade head

# Seed (opcional)
python3 scripts/reset_and_seed.py
```

## 4. Levantar API

```bash
pm2 start "gunicorn -w 4 -b 127.0.0.1:8000 main:app" --name jadslink-api
```

## 5. Acceder

```
https://wheat-pigeon-347024.hostingersite.com
Demo: demo@jadslink.com / demo123456
```

---

**Documentación completa**: `HOSTINGER_MYSQL_SETUP.md`
