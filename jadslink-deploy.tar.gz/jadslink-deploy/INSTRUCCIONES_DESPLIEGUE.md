# 🚀 Instrucciones de Despliegue JADSlink en Hostinger

## 📋 Requisitos Previos

- Acceso SSH al servidor Hostinger
- Python 3.9+
- PostgreSQL disponible en Hostinger
- Almacenamiento: ~500MB

## ⚡ Instalación Rápida (5 minutos)

### 1️⃣ Descargar y Extraer

```bash
# En tu servidor Hostinger
cd /home/u938946830/
unzip jadslink-deploy.zip
cd jadslink-deploy
```

### 2️⃣ Configurar Variables de Entorno

```bash
# Copiar template
cp .env.production .env

# Editar con tus credenciales de Hostinger
nano .env

# Importante: Actualizar estas líneas
# DATABASE_URL=postgresql://tu_usuario:tu_contraseña@localhost:5432/tu_bd
# SECRET_KEY=genera-nueva-clave
# TICKET_HMAC_SECRET=genera-nueva-clave-hmac
```

**Generar claves nuevas:**
```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

### 3️⃣ Ejecutar Script de Despliegue

```bash
chmod +x deploy-hostinger.sh
./deploy-hostinger.sh
```

El script hará automáticamente:
- ✅ Crear virtual environment Python
- ✅ Instalar dependencias
- ✅ Ejecutar migraciones de BD
- ✅ Aplicar seed de datos demo
- ✅ Compilar dashboard React (opcional)

### 4️⃣ Iniciar API

**Opción A: PM2 (Recomendado)**
```bash
npm install -g pm2
cd api
source venv/bin/activate
pm2 start "gunicorn -w 4 -b 127.0.0.1:8000 main:app" --name jadslink-api
pm2 save
pm2 startup
```

**Opción B: Systemd**
```bash
# El script deploy-hostinger.sh genera la configuración
# Luego ejecuta:
sudo systemctl enable jadslink-api
sudo systemctl start jadslink-api
```

### 5️⃣ Configurar Nginx (en panel Hostinger)

1. Ve al panel de Hostinger → Administrador de sitios web
2. Crea una entrada para `wheat-pigeon-347024.hostingersite.com`
3. En configuración Nginx, añade:

```nginx
location /api {
    proxy_pass http://127.0.0.1:8000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}

location / {
    # Servir el dashboard React
    alias /home/u938946830/jadslink-deploy/dashboard/dist/;
    try_files $uri $uri/ /index.html;
}
```

### 6️⃣ Verificar que Funcione

```bash
# Health check
curl http://localhost:8000/health

# Respuesta esperada:
# {"status":"healthy","checks":{"database":"ok"}}

# Acceder desde navegador:
# https://wheat-pigeon-347024.hostingersite.com
```

## 🔐 Credenciales Demo

Después del seed, usa:

- **Email**: demo@jadslink.com
- **Contraseña**: demo123456

O para superadmin:

- **Email**: admin@jads.com
- **Contraseña**: admin123456

## 🐛 Troubleshooting

### Error: "Cannot connect to database"
```bash
# Verificar credenciales en .env
psql postgresql://usuario:contraseña@localhost:5432/bd_name
```

### Error: "Module not found"
```bash
cd api
source venv/bin/activate
pip install -r requirements.txt
```

### Error: "Port 8000 in use"
```bash
# Cambiar puerto en gunicorn
gunicorn -w 4 -b 127.0.0.1:8001 main:app
```

## 📚 Documentación

- `HOSTINGER_SETUP.md` - Guía detallada
- `CLAUDE.md` - Arquitectura del proyecto
- `docs/TESTING_GUIDE.md` - Pruebas

## 🆘 Soporte

- GitHub Issues: [Repo Issues](https://github.com/adrpinto83/jadslink)
- Email: adrpinto83@gmail.com

---

**Status**: Listo para desplegar ✅
**Última actualización**: 2026-04-27
